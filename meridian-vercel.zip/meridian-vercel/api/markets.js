import { marketSnapshot, USD_RATES } from './_lib/markets.js';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed.' });
  const category = req.query.category;
  return res.status(200).json({ markets: marketSnapshot(category), usdRates: USD_RATES });
}
